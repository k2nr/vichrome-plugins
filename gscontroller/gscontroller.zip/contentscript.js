vichrome.plugins.addCommand({
    name: "GrooveSharkPlayStop",
    triggerType: "sendToBackground"
});
vichrome.plugins.addCommand({
    name: "GrooveSharkNext",
    triggerType: "sendToBackground"
});
vichrome.plugins.addCommand({
    name: "GrooveSharkPrevious",
    triggerType: "sendToBackground"
});
