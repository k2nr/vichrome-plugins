g.plugins.addCommand( {
    name: "SamplePluginCommand",
    triggerType: "triggerInsideContent",
    func: function() {
        alert( "hello, sample!");
    }
});
